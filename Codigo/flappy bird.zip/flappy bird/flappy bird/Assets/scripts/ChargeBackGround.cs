using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChargeBackGround : MonoBehaviour
{
    public static ChargeBackGround chargeBackGround;

    [SerializeField] private GameObject _day;
    [SerializeField] private GameObject _night;
   
    private void Awake()
    {
        if (chargeBackGround == null)
        {
            chargeBackGround = this;
        }

        Time.timeScale = 1f;
    }

    public void Charge(int punt)
    {
        if(punt/100%2==1)
        {
            _night.SetActive(true);
            _day.SetActive(false);    
            return;
        }
        _night.SetActive(false);
        _day.SetActive(true);
    }

   

}
